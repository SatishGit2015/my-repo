# setup-webserver.sh

This folder contains an example of a Bash script that can be used to install and Apache, PHP, and a sample PHP app
on an Ubuntu server. 

For more info, please see Chapter 1, "Why Terraform", of 
*[Terraform: Up and Running](http://www.terraformupandrunning.com)*.

## Pre-requisites

This script should be run on an Ubuntu server. 

## Quick start

```
./setup-webserver.sh
```