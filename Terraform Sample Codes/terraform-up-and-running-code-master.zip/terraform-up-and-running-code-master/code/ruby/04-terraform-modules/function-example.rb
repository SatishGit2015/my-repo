def example_function()
  puts "Hello, World"
end

# Other places in your code
example_function()
